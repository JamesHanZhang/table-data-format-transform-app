-- TABLE table_for_temp_use: table creation sql command based on database Oracle

CREATE TABLE table_for_temp_use(
    TABLE_AFFILIATION VARCHAR2(6),
    YEAR VARCHAR2(4),
    TRAN_NUMBER VARCHAR2(4),
    REMARK VARCHAR2(6)
);

COMMENT ON TABLE table_for_temp_use IS '临时表, 可删除';
